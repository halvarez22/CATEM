import React, { useState } from 'react';
import Header from './components/Header';
import ReportForm from './components/ReportForm';
import SubmissionSuccess from './components/SubmissionSuccess';
import TrackReport from './components/TrackReport';
import Dashboard from './components/Dashboard';
import type { View, ReportData, ReportStatus } from './types';
import { mockReports } from './data/mockReports';

const App: React.FC = () => {
  const [view, setView] = useState<View>('form');
  const [trackingId, setTrackingId] = useState<string | null>(null);
  const [reports, setReports] = useState<ReportData[]>(mockReports);

  const handleReportSubmitted = (report: ReportData) => {
    setTrackingId(report.id);
    setReports(prev => [report, ...prev]);
    setView('success');
  };
  
  const handleUpdateReport = (updatedReport: ReportData) => {
    setReports(prevReports => 
      prevReports.map(report => 
        report.id === updatedReport.id ? updatedReport : report
      )
    );
  };

  const handleNavigate = (newView: View) => {
    setView(newView);
  };

  const renderView = () => {
    switch (view) {
      case 'form':
        return <ReportForm onSubmitted={handleReportSubmitted} />;
      case 'success':
        return <SubmissionSuccess trackingId={trackingId!} onNavigate={handleNavigate} />;
      case 'track':
        return <TrackReport reports={reports} />;
      case 'dashboard':
        return <Dashboard reports={reports} onUpdateReport={handleUpdateReport} />;
      default:
        return <ReportForm onSubmitted={handleReportSubmitted} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#1a202c] text-slate-200 flex flex-col items-center p-4 sm:p-6 lg:p-8">
      <div className="w-full max-w-5xl">
        <Header onNavigate={handleNavigate} currentView={view} />
        <main className="mt-8">
          {renderView()}
        </main>
      </div>
       <footer className="w-full max-w-5xl mt-12 text-center text-xs text-slate-500">
          <p>&copy; 2025 CATEM</p>
          <p>Protegiendo los derechos de los trabajadores con tecnología segura.</p>
          <p className="mt-2">Powered by pai-b &copy; 2025 Todos los derechos reservados.</p>
        </footer>
    </div>
  );
};

export default App;
