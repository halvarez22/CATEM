import React, { useState, useMemo } from 'react';
import type { ReportData } from '../types';
import { ReportStatus } from '../types';
import ReportDetail from './ReportDetail';
import { SearchIcon } from './icons/SearchIcon';

interface DashboardProps {
  reports: ReportData[];
  onUpdateReport: (report: ReportData) => void;
}

const statusColors: Record<ReportStatus, string> = {
  [ReportStatus.RECIBIDO]: 'bg-blue-500/20 text-blue-300',
  [ReportStatus.EN_REVISION]: 'bg-yellow-500/20 text-yellow-300',
  [ReportStatus.INVESTIGACION]: 'bg-purple-500/20 text-purple-300',
  [ReportStatus.RESUELTO]: 'bg-green-500/20 text-green-300',
  [ReportStatus.CERRADO]: 'bg-slate-500/20 text-slate-400',
  [ReportStatus.NO_PROCEDE]: 'bg-red-500/20 text-red-400',
};

const severityColors: Record<string, string> = {
    'Baja': 'bg-gray-500/20 text-gray-300',
    'Media': 'bg-yellow-500/20 text-yellow-300',
    'Alta': 'bg-orange-500/20 text-orange-300',
    'Crítica': 'bg-red-500/20 text-red-300',
};

const Dashboard: React.FC<DashboardProps> = ({ reports, onUpdateReport }) => {
  const [selectedReport, setSelectedReport] = useState<ReportData | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  const filteredReports = useMemo(() => {
    return reports
      .filter(report => 
        statusFilter === 'All' || report.status === statusFilter
      )
      .filter(report =>
        report.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        report.title.toLowerCase().includes(searchTerm.toLowerCase())
      );
  }, [reports, searchTerm, statusFilter]);
  
  const handleUpdateAndGoBack = (updatedReport: ReportData) => {
    onUpdateReport(updatedReport);
    setSelectedReport(updatedReport); // Refresh the detail view with new data
  };

  if (selectedReport) {
    return (
      <ReportDetail
        report={selectedReport}
        onUpdateReport={handleUpdateAndGoBack}
        onBack={() => setSelectedReport(null)}
      />
    );
  }

  return (
    <div className="bg-[#2d3748] p-6 sm:p-8 rounded-lg shadow-2xl animate-fade-in">
      <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
        <div>
            <h2 className="text-2xl font-bold text-slate-100">Dashboard de Reportes</h2>
            <p className="text-sm text-slate-400 mt-1">Total de reportes: {reports.length}</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
            <div className="relative w-full sm:w-64">
                <input
                    type="text"
                    placeholder="Buscar por ID o título..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-[#374151] border border-[#4a5568] rounded-md py-2 pl-10 pr-4 text-slate-200 focus:ring-2 focus:ring-[#d69e2e] focus:border-[#d69e2e] transition"
                />
                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            </div>
            <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full sm:w-auto bg-[#374151] border border-[#4a5568] rounded-md p-2 text-slate-200 focus:ring-2 focus:ring-[#d69e2e] focus:border-[#d69e2e] transition"
            >
                <option value="All">Todos los Estados</option>
                {Object.values(ReportStatus).map(status => (
                    <option key={status} value={status}>{status}</option>
                ))}
            </select>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="bg-[#374151] text-xs text-slate-300 uppercase tracking-wider">
            <tr>
              <th className="p-3">ID de Seguimiento</th>
              <th className="p-3">Título</th>
              <th className="p-3">Severidad (IA)</th>
              <th className="p-3">Estado</th>
              <th className="p-3">Fecha</th>
              <th className="p-3">Acción</th>
            </tr>
          </thead>
          <tbody>
            {filteredReports.length > 0 ? filteredReports.map(report => (
              <tr key={report.id} className="border-b border-[#374151] hover:bg-[#3d4a5f] transition-colors">
                <td className="p-3 font-mono text-slate-300">{report.id}</td>
                <td className="p-3 max-w-xs truncate">{report.title}</td>
                <td className="p-3">
                     <span className={`px-2 py-1 text-xs font-semibold rounded-full ${severityColors[report.analysis?.severity ?? 'Baja']}`}>
                        {report.analysis?.severity ?? 'N/A'}
                    </span>
                </td>
                <td className="p-3">
                  <span className={`px-2 py-1 text-xs font-semibold rounded-full ${statusColors[report.status]}`}>
                    {report.status}
                  </span>
                </td>
                <td className="p-3 text-slate-400">{new Date(report.timestamp).toLocaleDateString()}</td>
                <td className="p-3">
                  <button onClick={() => setSelectedReport(report)} className="text-[#d69e2e] hover:text-[#e9b54f] font-semibold">
                    Ver Detalles
                  </button>
                </td>
              </tr>
            )) : (
                <tr>
                    <td colSpan={6} className="text-center p-8 text-slate-400">
                        No se encontraron reportes que coincidan con su búsqueda.
                    </td>
                </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Dashboard;
